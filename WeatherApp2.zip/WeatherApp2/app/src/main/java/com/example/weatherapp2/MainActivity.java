package com.example.weatherapp2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {
    JSONObject gJson;
    JSONObject gJson2;
    JSONArray hourlyArray;
    String lat;
    String lon;
    JSONObject hourlydata;
    TextView t;
    String data;
    String data2 = "";
    EditText e;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = findViewById(R.id.textView2);
        e = findViewById(R.id.editTextTextPersonName);
        b = findViewById(R.id.button);
        AsyncTaskDownloader asyncTaskDownloader = new AsyncTaskDownloader();
        AsyncTaskDownloader2 asyncTaskDownloader2 = new AsyncTaskDownloader2();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                asyncTaskDownloader.execute();
                asyncTaskDownloader2.execute();
            }
        });
    }

    public class AsyncTaskDownloader extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings){
            data = "";
            try {
                String zip = e.getText().toString();
                String country = "us";
                URL myUrl = new URL("https://api.openweathermap.org/geo/1.0/zip?zip=" + zip + "," + country + "&appid=fbb811970a743b3e2785939123d8e8fa");
                HttpURLConnection connection = (HttpURLConnection) myUrl.openConnection();
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String inputLine = "";
                while (inputLine != null){
                    inputLine = br.readLine();
                    stringBuilder.append(inputLine);
                }
                data = stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("Error", e.toString());
                data = null;
            }
            //Log.d("DATA", data);
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            //super.onPostExecute(s);
            try {
                gJson = new JSONObject(s);
                lat = gJson.getString("lat");
                lon = gJson.getString("lon");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.d("tag", gJson.toString());
            Log.d("lon", lon);
            Log.d("lat", lat);
            t.setText(gJson.toString());
        }

    }
    public class AsyncTaskDownloader2 extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            try {
                data2 = "";
                URL myUrl = new URL("https://api.openweathermap.org/data/2.5/onecall?lat=" + lat + "&lon=" + lon + "&exclude=current,minutely,daily&appid=fbb811970a743b3e2785939123d8e8fa");
                HttpURLConnection connection = (HttpURLConnection) myUrl.openConnection();
                connection.connect();
                InputStreamReader inputStreamReader = new InputStreamReader(connection.getInputStream());
                BufferedReader br = new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder = new StringBuilder();
                String inputLine = "";
                while ((inputLine = br.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
                br.close();
                inputStreamReader.close();
                //connection.disconnect();
                data2 = stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                data2 = null;
            }
            return data2;
        }

        @Override
        protected void onPostExecute(String s) {
            //super.onPostExecute(s);
            try {
                gJson2 = new JSONObject(s);
                //fixthishitbru: hourlydata = new JSONObject(String.valueOf(gJson2.getJSONArray("hourly")));
                //lon = gJson2.getString("lon");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.d("obj", gJson2.toString());
            t.setText(gJson2.toString());
        }
    }
}